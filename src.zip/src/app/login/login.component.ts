import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../model/user';
import { UserService } from '../user.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  value="something"
  users:User[]=[]
  loginform!:FormGroup; 
  mail = " "
  pass=""

  constructor(private formBuilder:FormBuilder,private service:UserService, private router:Router) { }

  ngOnInit(): void {
    this.users = this.service.getusers();
    this.creatloginform();
  }
  creatloginform(){
    this.loginform= this.formBuilder.group({
      email:[''],
      password:[''],
    });
  }
  onSubmit(){
    this.mail = this.loginform.value.email
    this.pass=this.loginform.value.password
    let users= this.service.getusers()
    for( let user of users){
        if(user.email== this.mail && user.password == this.pass){
             this.router.navigate(['/profile/userdetails',this.mail]);
             return
      }
    }
    alert("USER NAME OR PASSWORD INCORRECT" )
  }



}
