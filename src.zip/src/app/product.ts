
     export class Product{

      title:String
      name:String
      price:number
      img:String
      constructor(title:String,name:String,price:number,img:string){
    this.title=title
    this.name=name
    this.price=price
    this.img=img
      }
     }
     