export class User{
    name: string
    email : string
    password : string
    birthday:string
    Gender:string
    constructor(name:string , email:string,password:string,birthday:string,Gender:string){
        this.name=name
        this.email=email
        this.password=password
        this.birthday=birthday
        this.Gender=Gender
    }
}