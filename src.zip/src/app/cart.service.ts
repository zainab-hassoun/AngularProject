import { Injectable } from '@angular/core';
import { Cart, CartProduct } from './cartProduct';
import { Product } from './product';


@Injectable({
  providedIn: 'root'
})
export class CartService {
  cart : Cart = new Cart()
  constructor() { }
  addToCart(product : Product){
    this.cart.addproduct(product)
  }
  getProducts(){
   return this.cart.getproduct()
  }

  removeFromCart(product:Product){
    this.cart.removeproduct(product)
  }
  clearCart(cart:Cart){
    this.cart.clear(this.cart)
  }
  removept(product:Product){
    this.cart.removept(product)
  }
  
}
