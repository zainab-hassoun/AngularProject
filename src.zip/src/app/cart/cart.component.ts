import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { CartService } from '../cart.service';
import { Cart } from '../cartProduct';
import { Product } from '../product';
import { UserService } from '../user.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart !: Cart
  constructor(private cartservisc:CartService,private userservice:UserService,private router:Router,private formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.cart = this.cartservisc.cart
  }
  isloggedin(){
    return this.userservice.islogginIn()  
    } 

  add(product: Product){
this.cartservisc.addToCart(product)
  }
  sub(product: Product){
    this.cartservisc.removeFromCart(product)
  }
  remove(product: Product){
    this.cartservisc.removeFromCart(product)
  }
clear(cart:Cart){
  this.cartservisc.clearCart(cart)
}

pay(){

}
removept(product:Product){
this.cartservisc.removept(product)
}
}
