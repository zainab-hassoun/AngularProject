import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { User } from '../model/user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {
  mail :string = ""
  name :string=""
  gender : string = ""
  birthday:string=""
  constructor(private service:UserService, private actRoute:ActivatedRoute) { }

  ngOnInit(): void {
    this.mail = this.actRoute.snapshot.params["mail"];
    let user = this.service.getUser(this.mail)
    if(user != null){
      this.name = user.name
      this.gender = user.Gender
      this.birthday = user.birthday
    }
  }

}
