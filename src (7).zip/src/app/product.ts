
     export class Product{

      title:String
      name:String
      price:number
      image:String
      constructor(title:String,name:String,price:number,img:string){
    this.title=title
    this.name=name
    this.price=price
    this.image=img
      }
     }
     