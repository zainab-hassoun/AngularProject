
import { Component, Input, OnInit,OnChanges,SimpleChanges } from '@angular/core';
import{productservice} from '../product.service';
import{Product} from '../product';
import { ActivatedRoute } from '@angular/router';
import { CartService } from '../cart.service';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  meals:Product[]=[]
  _option : string = ""
  @Input()  
  set option(option: string) {
    this._option = option
    if(this.option== "All")
      this.meals= this.productservice.getAllproduct();
    else if(this.option== "Salads")
      this.meals = this.productservice.getSaladsproduct();
    else if(this.option== "Main")
      this.meals = this.productservice.getMainproduct();
    else
      this.meals= this.productservice.getStartersproduct();
  }
  get option(): string {
    return this._option 
  }

  constructor(private productservice:productservice,private cartservise:CartService) { }

  ngOnInit(): void {
    this.meals = this.productservice.getAllproduct()
  }

  add(product:Product){
    this.cartservise.addToCart(product);
  }
}
