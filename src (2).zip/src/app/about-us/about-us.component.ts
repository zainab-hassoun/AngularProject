import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})
export class AboutUsComponent implements OnInit {
  img1 = 'assets/elsa.webp'
  student1 = 'Heba ID:211508643'
  img2 = 'assets/frozen.webp'
  student2 = 'Zainab ID:212790745'
  mail1='Hebaabu2001@hotmail.com'
  mail2='zainabhassoun123@gmail.com'
title1='Student'
title2='Student'
inf1='In Ort Braude'
inf2="In Ort Braude"

  constructor() { }

  ngOnInit(): void {
  }
  islight=true;
  Text="light";
  Text1="dark";
    
  color():void{
    var x;
    if(this.islight){
       this.islight=!this.islight;
       this.Text="dark";
    }
    else{
      this.islight=!this.islight;
      this.Text="light";
    }
    
  
  }
}
