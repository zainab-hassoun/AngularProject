import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { User } from './model/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  users : User[] = [
    new User("heba","heba@hotmail.com","123","2442001","female"),
    new User("alex","alex@hotmail.com","12345","2152001","male")
  ]
  constructor(private router :Router) { }
  
  getusers(){
    return this.users 
  }

  isExists(mail:string){
    for(let User of this.users){
      if(mail== User.email)
        return true
    }
    return false
  } 
  login(mail:string,pass:string){
for(let user of this.users)
if(user.email==mail && user.password == pass){
  localStorage.setItem('currentuser',mail);
  if(user.Gender=='male')
  localStorage.setItem('img','https://th.bing.com/th/id/OIP.LftRMxkISZ37h5xsxfDCWQHaHa?pid=ImgDet&rs=1');
  else
  localStorage.setItem('img','https://th.bing.com/th/id/OIP.GIX5K_H6IcDTpUBcApSiEQHaHa?pid=ImgDet&w=201&h=201&c=7&dpr=1.3');
  return true
}
return false
  }
  logout(){
    localStorage.removeItem('currentuser')
    localStorage.removeItem('img')
  }

  adduser(name:string , mail:string , pass:string ,birthday:string,Gender:string ){
    let user = new User (name,mail,pass,birthday,Gender)
    this.users.push(user)
  }
  islogginIn(){
    if(localStorage.getItem('currentuser'))
      return true;
    return false
  }
  getUser(mail:string){
    for(let user of this.users){
      if(mail== user.email)
        return user
    }
    return null
  }
  
}
